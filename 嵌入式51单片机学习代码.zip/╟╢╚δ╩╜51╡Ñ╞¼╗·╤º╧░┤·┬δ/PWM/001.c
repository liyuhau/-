#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char
sbit PWM_LED0=P1^1;
uint times=0;
void Delay()	
{ 
    uchar i;
	for(i=111;i>0;i--);
} 
void main()
{	uchar highwide=95;
    while(1)
	{
	  	 uchar a=0;
         PWM_LED0=1;
	     for(a=0;a<100-highwide;a++)
	     { 
	         Delay();
	     }
	     PWM_LED0=0;
	     for(a=0;a<highwide;a++)
	     { 
	         Delay();
	     }
		 times++;
		 if(times==100)
		 {
		      times=0;
			  highwide=highwide-5;
			  if(highwide==0)  highwide=95;
		 }
	}
    
}