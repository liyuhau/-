#include<reg51.h>
#include <intrins.h>
#define uint unsigned int 
#define uchar unsigned char 
sbit pwm=P1^0;
uint count=0,timer1=0,value=0;
uchar DIR=1;
void main()
{
    TMOD=0x01;
    TH0=(65536-1)/256;
    TL0=(65536-1)%256;
    EA=1;//�����ж�
    ET0=1;//����ʱ��0�ж�
    TR0=1;//TR0��λ��������ʱ��
    while(1)
    {
           if(timer1>value)
           {
  	             pwm=0;
           }
           else 
           {
                 pwm=1;
           }

    }
}

void time0() interrupt 1
{
      TH0=(65536-1)/256;
      TL0=(65536-1)%256;
      timer1++;
      count++;
      if(timer1>250)   //timer1/count����ռ�ձ����ӻ���ٵĿ���ʱ��
      {
         timer1=0;
      }
      if(count>100)    //T=(value/(timer1/count))*timer1
      {
         count=0;
  	       if(DIR==1)
           {
              value++;	  
           }			 
           if(DIR==0)	 
           {
               value--;
           }
       }
     if(value==250)  
     {
  	     DIR=0;
     }
     if(value==0)
     {
  	     DIR=1;
     }

}