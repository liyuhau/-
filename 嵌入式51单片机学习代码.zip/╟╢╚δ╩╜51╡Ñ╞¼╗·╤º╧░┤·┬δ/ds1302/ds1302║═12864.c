#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
sbit cs=P3^4;
sbit sid=P3^5;
sbit sclk=P3^6;
sbit psb=P3^7;
sbit rst=P2^3;
sbit io=P2^4;
sbit clk=P2^5;
uchar time_init[8]={0x20,0x19,0x06,0x09,0x23,0x59,0x58,0x07};
uchar add_table[8]={0x8c,0x8c,0x88,0x86,0x84,0x82,0x80,0x8a};
uchar num=0;
/************************************12864��ʾ**************************************/
void delay(uchar z)
{
     uchar i,j;
        for(i=z;i>0;i--)
         for(j=110;j>0;j--);                     
}
void sendbyte(uchar byte)
{
        uchar i;
        for(i=0;i<8;i++)
        {
                sclk=1;
                if(byte&0x80)
                   sid=1;
                else
                   sid=0;
                sclk=0;
                byte<<=1;
        }
}
void write_cmd(uchar cmd)
{
        cs=1;
        sendbyte(0xf8);
        sendbyte(cmd&0xf0);
        sendbyte(cmd<<4&0xf0);
        cs=0;
        delay(10);
}
void write_data(uchar date)
{
        cs=1;
        sendbyte(0xfa);
        sendbyte(date&0xf0);
        sendbyte(date<<4&0xf0);
        cs=0;
        delay(10);
}
void dizhi(uchar x,uchar y)
{
        uchar address;
        switch(x)
        {
                case 1:address=0x80+y;break;
                case 2:address=0x90+y;break;
                case 3:address=0x88+y;break;
                case 4:address=0x98+y;break;
        }
        write_cmd(address);        
}
void zhizhen(uchar *s)
{
        while(*s)
        {
             write_data(*s);
                s++;
        }
}

void init()
{
     psb=0;
     write_cmd(0x30);
     write_cmd(0x01);
     write_cmd(0x02);
     write_cmd(0x06);
     write_cmd(0x0e);
}
/**********************************ds1302******************************************/

void ds1302_write(uchar address,uchar date)
{
	int i;
	rst=1;
	address=address&0xfe;
	for(i=0;i<8;i++)
	{
		clk=0;
		if(address&0x01)
		{
			io=1;
		}
		else
		{
			io=0;
		}
		clk=1;
		clk=0;
		address>>=1;
	}
	for(i=0;i<8;i++)
	{
		clk=0;
		if(date&0x01)
		{
			io=1;
		}
		else
		{
			io=0;
		}
		clk=1;
		clk=0;
		date>>=1;
	}
	rst=0;
}

uchar ds1302_read(uchar add)
{
	uchar i,temp;
	rst=1;
	add=add|0x01;
	for(i=0;i<8;i++)
	{
		clk=0;
		if(add&0x01)
		{
			io=1;
		}
		else
		{
			io=0;
		}
		clk=1;
		clk=0;
		add>>=1;	
	}
	for(i=0;i<8;i++)
	{	temp>>=1;
		if(io)
		{
			temp|=0x80;	
		}
		else
		{
			temp&=0x7f;
		}
		clk=1;
		clk=0;
			
	}
	rst=0;
	return temp;
}

void ds1302_write_time()
{
	int i;
	uchar init_data;
	init_data=ds1302_read(0x80);
	if(init_data&0x80!=0)
	{
		ds1302_write(0x8e,0x00);
		for(i=1;i<8;i++)
		{
			ds1302_write(add_table[i],time_init[i]);
		}
		ds1302_write(0x8e,0x80);
	}
	
}

void ds1302_read_time()
{
	int i;
	for(i=1;i<8;i++)
	{
		time_init[i]=ds1302_read(add_table[i]);
	}
}
void ds1302_init()
{
	rst=0;
	clk=0;

}
void display()
{
	uchar week,i;
	uchar time_read[]={0,0,0,0,0x2f,0,0,0x2f,0,0};
	uchar time_table[]={0,0,0x3a,0,0,0x3a,0,0};
	ds1302_read_time();
	if(num==4)
	{
		TR0=0;
		num=0;
		time_read[0]=(time_init[0]>>4)+0x30;
		time_read[1]=(time_init[0]&0x0f)+0x30;
		time_read[2]=(time_init[1]>>4)+0x30;
		time_read[3]=(time_init[1]&0x0f)+0x30;
		time_read[5]=(time_init[2]>>4)+0x30;
		time_read[6]=(time_init[2]&0x0f)+0x30;
		time_read[8]=(time_init[3]>>4)+0x30;
		time_read[9]=(time_init[3]&0x0f)+0x30;
		dizhi(1,0);
		for(i=0;i<10;i++)
		{
			write_data(time_read[i]);	
		}

		week=(time_init[7]&0x0f)+0x30;
		dizhi(2,0);
		zhizhen("����");
		dizhi(2,2);
		write_data(week);	
	
		time_table[0]=(time_init[4]>>4)+0x30;
		time_table[1]=(time_init[4]&0x0f)+0x30;
		time_table[3]=(time_init[5]>>4)+0x30;
		time_table[4]=(time_init[5]&0x0f)+0x30;
		time_table[6]=(time_init[6]>>4)+0x30;
		time_table[7]=(time_init[6]&0x0f)+0x30;
		dizhi(3,0);
		for(i=0;i<8;i++)
		{
			write_data(time_table[i]);	
		}
		TR0=1;
	}	
}

void time0_init()
{
	TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	ET0=1;
	TR0=1;
	EA=1;
}
void main()
{
	delay(50);
	init();
	ds1302_init();
	delay(10);
	ds1302_write_time();
	delay(10);
	time0_init();
	while(1)
	{	
		display();
	}	
}

void time0() interrupt 1
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	num++;		
} 