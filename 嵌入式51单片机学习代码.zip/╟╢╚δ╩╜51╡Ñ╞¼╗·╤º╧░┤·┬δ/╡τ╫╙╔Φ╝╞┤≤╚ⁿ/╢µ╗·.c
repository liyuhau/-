#include<reg51.h>
#define uint unsigned int 
uint pp;
sbit pwm=P2^2;
void main()
{
        TMOD=0x02;                
        TH0=0xfd;                 
        TL0=0xfd;
        ET0=1;                         
        EA=1;                         
        TR0=1;                         
        while(1)
        {
                if(pp<=40)       
                        pwm=1;
                else
                        pwm=0;
                if(pp==80)
                        pp=0;
        }
}

void time0() interrupt 1
{        
        pp++;
}