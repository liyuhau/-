#include<reg51.h>
//#include<string.h>
#define uchar unsigned char
sbit led=P2^7;
uchar flag=0;	
uchar a[];
uchar code table[]={0x00,0x7B,0x7C,0xCB,0xCC};
//uchar code t1[]="007BA532EC";
void init()
{
	TMOD=0x20;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	REN=1;
	SM0=0;
	SM1=1;
	EA=1;
	ES=1;
}
void main()
{
	uchar i,k;
	init();
	while(1)
	{
		k=0;
		i=0;
		if(flag==5)
		{	
			flag=0;
			ES=0;
			for(i=0;i<5;i++)
			{
				if(a[i]==table[i])
				k++;	
			}
			//if(strcmp(a,t1)==0)
		//k++;
			if(k==5)
			led=~led;
			
			ES=1;
			//flag=0;
			
		}	
		}
	}
	

void py() interrupt 4
{
	uchar date;
	RI=0;
	date=SBUF;
	if(date!=0xff)
	{
	a[flag]=date;
	flag++;}
}