#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
uchar jiemi[5],sum=0;
uint pp;
sbit led=P2^7;
uchar code mima[]={0x00,0x7B,0x7C,0x9D,0x9A};

void ckzd_init()
{
	TMOD=0x20;
	TL1=0xfd;
	TH1=0xfd;
	TR1=1;
	REN=1;
	SM0=0;
	SM1=1;
	EA=1;
	ES=1;
}

void display()
{
	uchar i,k;	 
		k=0;i=0;
		if(sum==5)
		{	
			sum=0;
			ES=0;
			for(i=0;i<5;i++)
			{
				if(mima[i]==jiemi[i])
				k++;
			}
			if(k==5)
			{	
				led=~led;
			}
			ES=1;
		}	

}
void main()
{
	
	ckzd_init();
	while(1)
	{
		display();
	}
}

void ser() interrupt 4
{
	uchar date;
	RI=0;
	TI=0;
	date=SBUF;
	if(date!=0xff)
	{
		jiemi[sum]=date;
		sum++;
	}

}