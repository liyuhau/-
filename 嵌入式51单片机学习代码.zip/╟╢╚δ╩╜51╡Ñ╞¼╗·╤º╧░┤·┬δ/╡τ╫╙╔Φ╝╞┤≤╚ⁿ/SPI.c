#include<reg51.h>
sbit scl=P2^0;
sbit output=P2^1;
sbit input=P2^2;
typedef unsigned char uc;
void delay(int n)//ms��ʱ
{
  unsigned int i,j;
  for(j=n;j>0;j--)
  for(i=112;i>0;i--);
}
uc readwritebyte(uc date)
{
	int i;
	uc indate;
	indate=0;
 for(i=0;i<8;i++)
	{
		indate=indate<<1;
    scl=0;
    output=date&0x80;
	  indate|=input;
    scl=1;			
		date=date<<1;
	}
	return indate;
}
void spiinit()//��spi���г�ʼ��
{
 scl=1;
 output=1;
 input=1;//��ʼ��ʱ�Ӻ��������Ϊ1 ��Ϊ32�����øߵ�ƽΪ
	       //����״̬
}
void main()
{  uc date;
	int i=0;
	 uc hrhr[10]={'h','c','o'};
   
	 	   spiinit();
	 while(1)
	 {
	 date=readwritebyte(hrhr[i]);
   P1=date;
   delay(500);
		if(i<2)
		{
		 i++;
		}
		else i=0;		 
	 }
}
