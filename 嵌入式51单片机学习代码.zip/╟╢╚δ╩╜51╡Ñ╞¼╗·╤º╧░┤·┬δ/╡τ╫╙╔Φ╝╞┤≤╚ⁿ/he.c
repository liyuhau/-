#include<reg51.h>
#include<intrins.h>
#include<math.h>
#define uchar unsigned char
#define uint unsigned int
sbit scl=P2^1;		  //iicʱ��
sbit sda=P2^2;
sbit dh=P2^3;
sbit SCL=P2^4;		 //spiʱ��
sbit output=P2^5;
sbit input=P2^6;
sbit led=P2^7;
uchar jiemi[5],sum=0;					   //ˢ��
uchar code mima[]={0x00,0x7B,0x7C,0x9D,0x9A};
uchar RH_H,T_H;
uchar num,flag=0;
uchar temp,com_data;
uchar RH_date1,RH_date2,T_date1,T_date2,check_date;
uchar RH_temp1,RH_temp2,T_temp1,T_temp2;

/*************************************24c02**************************************/
void delay5us()
{ ;; }

void start()
{
	sda=1;
	delay5us();
	scl=1;
	delay5us();
	sda=0;
	delay5us();
}


void stop()
{
	sda=0;
	delay5us();
	scl=1;
	delay5us();
	sda=1;
	delay5us();
}

void respons()
{
	uchar i;
	scl=1;
	delay5us();
	while(sda==1&&i<255)
		i++;
	scl=0;
	delay5us();	
}

void write_date(uchar date)
{
	uchar i,temp;
	temp=date;
	for(i=0;i<8;i++)
	{
		temp<<=1;
		scl=0;
		delay5us();
		sda=CY;
		delay5us();
		scl=1;
		delay5us();
	}
	scl=0;
	delay5us();
	sda=1;
	delay5us();
}

uchar read_date()
{
	 uchar i,j,k;
	 scl=0;
	 delay5us();
	 sda=1;
	 delay5us();
	 for(i=0;i<8;i++)
	 {
	 	scl=1;
		delay5us();
		if(sda==1)
		   j=1;
		else
		   j=0;
		k=k<<1|j;
		scl=0;
		delay5us();
	 }
	 return k;
}

void iic24c_init()
{
	scl=1;
	delay5us();
	sda=1;
	delay5us();
}

void write_add(uchar address,uchar date)
{
	start();
	write_date(0xa0);
	respons();
	write_date(address);
	respons();
	write_date(date);
	respons();
	stop();
}

uchar read_add(uchar address)
{
	uchar date;
	start();
	write_date(0xa0);
	respons();
	write_date(address);
	respons();
	start();
	write_date(0xa1);
	respons();
	date=read_date();
	stop();
	return date;
}
/*************************************������ʾ***********************************/
uchar code table[10][8]=
{
	{0xC1,0xBE,0xBE,0xC1,0xFF,0xFF,0xFF,0xFF},/*"0",0*/
	{0xDE,0x80,0xFE,0xFF,0xFF,0xFF,0xFF,0xFF},/*"1",1*/
	{0xDC,0xBA,0xB6,0xCE,0xFF,0xFF,0xFF,0xFF},/*"2",2*/
	{0xDD,0xB6,0xB6,0xC9,0xFF,0xFF,0xFF,0xFF},/*"3",3*/
	{0xF1,0xCD,0x80,0xFD,0xFF,0xFF,0xFF,0xFF},/*"4",4*/
	{0x86,0xB6,0xB6,0xB9,0xFF,0xFF,0xFF,0xFF},/*"5",5*/
	{0xC1,0xB6,0xB6,0xD9,0xFF,0xFF,0xFF,0xFF},/*"6",6*/
	{0x9F,0xB8,0xB7,0x8F,0xFF,0xFF,0xFF,0xFF},/*"7",7*/
	{0xC9,0xB6,0xB6,0xC9,0xFF,0xFF,0xFF,0xFF},/*"8",8*/
	{0xCD,0xB6,0xB6,0xC1,0xFF,0xFF,0xFF,0xFF},/*"9",9*/
};

uchar code table1[10][8]=
{
	{0xFF,0xFF,0xFF,0xFF,0xC1,0xBE,0xBE,0xC1},/*"0",0*/
	{0xFF,0xFF,0xFF,0xFF,0xDE,0x80,0xFE,0xFF},/*"1",1*/
	{0xFF,0xFF,0xFF,0xFF,0xDC,0xBA,0xB6,0xCE},/*"2",2*/
	{0xFF,0xFF,0xFF,0xFF,0xDD,0xB6,0xB6,0xC9},/*"3",3*/
	{0xFF,0xFF,0xFF,0xFF,0xF1,0xCD,0x80,0xFD},/*"4",4*/
	{0xFF,0xFF,0xFF,0xFF,0x86,0xB6,0xB6,0xB9},/*"5",5*/
	{0xFF,0xFF,0xFF,0xFF,0xC1,0xB6,0xB6,0xD9},/*"6",6*/
	{0xFF,0xFF,0xFF,0xFF,0x9F,0xB8,0xB7,0x8F},/*"7",7*/
	{0xFF,0xFF,0xFF,0xFF,0xC9,0xB6,0xB6,0xC9},/*"8",8*/
	{0xFF,0xFF,0xFF,0xFF,0xCD,0xB6,0xB6,0xC1},/*"9",9*/
};


void delay(int x)
{
	uint i,j;
	for(i=0;i<x;i++)
	{
		for(j=0; j < 500; j++);
	}		
}
/*************************************spi***************************************/
void delayms(int n)//ms��ʱ
{
  uint i,j;
  for(j=n;j>0;j--)
  for(i=112;i>0;i--);
}
uchar readwritebyte(uchar date)
{
	int i;
	uchar indate;
	indate=0;
 for(i=0;i<8;i++)
	{
		indate=indate<<1;
    SCL=0;
    output=date&0x80;
	  indate|=input;
    SCL=1;			
		date=date<<1;
	}
	return indate;
}
void spiinit()//��spi���г�ʼ��
{
 SCL=1;
 output=1;
 input=1;//��ʼ��ʱ�Ӻ��������Ϊ1 ��Ϊ32�����øߵ�ƽΪ
	       //����״̬
}
/********************************dht11��ʾ*************************************/
void delay100us(uint j)
{
	uchar i;
	for(;j>0;j--)
	{
		for(i=0;i<27;i++);
	}
}

void delay10us()
{
	uchar i;
	i--;
	i--;
	i--;
	i--;
	i--;
	i--;
}

void read_byte()
{
	uchar i;
	for(i=0;i<8;i++)
	{
		num=2;
		while((!dh)&&num++);    //num�ӵ�256���ʱ��num=0;��ʱwhile����Ϊ0���˳�ѭ����2~256���1ms
		delay10us();
		delay10us();		  
		delay10us();
		temp=0;
		if(dh) temp=1;
		num=2;
		while((dh)&&num++);//��ʱ������forѭ��
		if(num==1) break;//�ж�����λ��0����1������ߵ�ƽ�߹�Ԥ��0���ߵ�ƽֵ������λΪ1
		com_data<<=1;
		com_data|=temp;
	}
}

void RH()
{
	dh=0;
	delay100us(180);//��������18ms
	dh=1;    //�����������������ߣ�������ʱ20us
	delay10us();
	delay10us();
	delay10us();
	delay10us(); //������Ϊ���룬�жϴӻ���Ӧ�ź�
	dh=1;  
	if(!dh)  //�жϴӻ��Ƿ��е͵�ƽ��Ӧ�źţ��粻��Ӧ����������Ӧ�����½���
	{
		num=2;
		while((!dh)&&num++);//�жϴӻ��Ƿ񷢳�80us�ĵ͵�ƽ��Ӧ�ź��Ƿ����
		num=2;
		while((dh)&&num++);//�жϴӻ��Ƿ񷢳�80us�ĸߵ�ƽ���緢����������ݽ���״̬
		read_byte();	    //���ݽ���״̬
		RH_date1=com_data;
		read_byte();
		RH_date2=com_data;
		read_byte();
		T_date1=com_data;
		read_byte();
		T_date2=com_data;
		read_byte();
		check_date=com_data;
		dh=1;
		temp=(RH_date1+RH_date2+T_date1+T_date2); //����У��
		if(temp==check_date)
		{
			RH_temp1=RH_date1;
			RH_temp2=RH_date1;
			T_temp1=T_date1;
			T_temp2=T_date1;
		}
	}
	delay100us(1000);//ÿ�ζ�dht11���1s����
}
/*************************************51ˢ��************************************/
void ckzd_init()
{
	TMOD=0x20;
	TL1=0xfd;
	TH1=0xfd;
	TR1=1;
	REN=1;
	SM0=0;
	SM1=1;
	EA=1;
	ES=1;
}


/************************************88��ʾ*************************************/
void xianshi88()
{ 	
	int xianshi[]={0,0};
	int iic_date,j,k,shiwei,gewei;
	iic24c_init();
	P0=0x80;
	while(1)
	{
		RH();					  //8*8������ʾ
		RH_H=RH_temp1;
		write_add(0x03,RH_H);
		delay(100);
		iic_date=read_add(0x03);
		xianshi[0]=iic_date/10;
		xianshi[1]=iic_date%10;
		shiwei=xianshi[0];gewei=xianshi[1];
		for(j=0;j<40;j++)
		{	
			for(k=0;k<8;k++)
			{
		     	if(k<4)
				{	
					P1=0xff;
					P1=table[shiwei][k];
					P0=_crol_(P0,1);
					delay(1);
				}
				else
				{
					P1=0xff;
					P1=table1[gewei][k];
					P0=_crol_(P0,1);
					delay(1);
				}
			}
			P0=0x80;
			P1=0xff;
		}
	}
}
/*************************************������************************************/
void main()
{   
	uchar wendu[]={0,0};
	uchar shidu[]={0,0};
	uchar t,rh,T_H,RH_H;
	int spi_i=0,bzw,mbzw;
	spiinit();
	ckzd_init();	
	while(1)
	{	
		xianshi88();
		RH();
		T_H=T_temp1;
		wendu[0]=0x30+T_H/10;
		wendu[1]=0x30+T_H%10;

		RH();
		RH_H=RH_temp1;
		shidu[0]=0x30+RH_H/10;
		shidu[1]=0x30+RH_H%10;
		t=readwritebyte(wendu[spi_i]);
		delayms(500);
		rh=readwritebyte(shidu[spi_i]);
		delayms(500);
		if(spi_i<2)
		{
		 spi_i++;
		}
		else spi_i=0;

		if(flag==1)
		    bzw=1;
		else
		    bzw=0;
		mbzw=readwritebyte(bzw);
		delayms(500);	 
	}
}
void ser() interrupt 4
{
	uchar date;
	uchar i,k;
	RI=0;
	TI=0;
	date=SBUF;
	if(date!=0xff)
	{
		jiemi[sum]=date;
		sum++;
		if(sum==5)
		{	
			sum=0;
			for(i=0;i<5;i++)
			{
				if(mima[i]==jiemi[i])
				k++;
			}
			if(k==5)
			{	
				led=~led;
				flag=1;
			}
			k=0;
		}
	}
}