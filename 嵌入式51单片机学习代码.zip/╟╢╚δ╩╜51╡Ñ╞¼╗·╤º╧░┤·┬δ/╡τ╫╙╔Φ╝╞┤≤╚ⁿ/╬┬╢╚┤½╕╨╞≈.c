#include<reg51.h>
#include<intrins.h>
#include<math.h>
#define uchar unsigned char
#define uint unsigned int
sbit scl=P2^6;
sbit sda=P2^7;
sbit dh=P2^3;
sbit CS=P3^4;
sbit SID=P3^5;
sbit SCLK=P3^6;
sbit PSB=P3^7;
uchar num;
uchar temp,com_data;
uchar RH_date1,RH_date2,T_date1,T_date2,check_date;
uchar RH_temp1,RH_temp2,T_temp1,T_temp2;
/******************************Һ����ʾ����******************************/
void delay(uchar z)
{
     uchar i,j;
        for(i=z;i>0;i--)
         for(j=110;j>0;j--);                     
}
void sendbyte(uchar byte)
{
        uchar i;
        for(i=0;i<8;i++)
        {
                SCLK=1;
                if(byte&0x80)
                   SID=1;
                else
                   SID=0;
                SCLK=0;
                byte<<=1;
        }
}
void write_cmd(uchar cmd)
{
        CS=1;
        sendbyte(0xf8);
        sendbyte(cmd&0xf0);
        sendbyte(cmd<<4&0xf0);
        CS=0;
        delay(10);
}
void write_data(uchar date)
{
     CS=1;
        sendbyte(0xfa);
        sendbyte(date&0xf0);
        sendbyte(date<<4&0xf0);
        CS=0;
        delay(10);
}
void dizhi(uchar x,uchar y)
{
        uchar address;
        switch(x)
        {
                case 1:address=0x80+y;break;
                case 2:address=0x90+y;break;
                case 3:address=0x88+y;break;
                case 4:address=0x98+y;break;
        }
        write_cmd(address);        
}
void guding(uchar *s)
{
        while(*s)
        {
             write_data(*s);
                s++;
        }
}
void init()
{
     PSB=0;
     write_cmd(0x30);
     write_cmd(0x01);
     write_cmd(0x02);
     write_cmd(0x06);
     write_cmd(0x0e);
}
/********************************dht11��ʾ*************************************/
void delay100us(uint j)
{
	uchar i;
	for(;j>0;j--)
	{
		for(i=0;i<27;i++);
	}
}

void delay10us()
{
	uchar i;
	i--;
	i--;
	i--;
	i--;
	i--;
	i--;
}

void read_byte()
{
	uchar i;
	for(i=0;i<8;i++)
	{
		num=2;
		while((!dh)&&num++);    //num�ӵ�256���ʱ��num=0;��ʱwhile����Ϊ0���˳�ѭ����2~256���1ms
		delay10us();
		delay10us();		  
		delay10us();
		temp=0;
		if(dh) temp=1;
		num=2;
		while((dh)&&num++);//��ʱ������forѭ��
		if(num==1) break;//�ж�����λ��0����1������ߵ�ƽ�߹�Ԥ��0���ߵ�ƽֵ������λΪ1
		com_data<<=1;
		com_data|=temp;
	}
}

void RH()
{
	dh=0;
	delay100us(180);//��������18ms
	dh=1;    //�����������������ߣ�������ʱ20us
	delay10us();
	delay10us();
	delay10us();
	delay10us(); //������Ϊ���룬�жϴӻ���Ӧ�ź�
	dh=1;  
	if(!dh)  //�жϴӻ��Ƿ��е͵�ƽ��Ӧ�źţ��粻��Ӧ����������Ӧ�����½���
	{
		num=2;
		while((!dh)&&num++);//�жϴӻ��Ƿ񷢳�80us�ĵ͵�ƽ��Ӧ�ź��Ƿ����
		num=2;
		while((dh)&&num++);//�жϴӻ��Ƿ񷢳�80us�ĸߵ�ƽ���緢����������ݽ���״̬
		read_byte();	    //���ݽ���״̬
		RH_date1=com_data;
		read_byte();
		RH_date2=com_data;
		read_byte();
		T_date1=com_data;
		read_byte();
		T_date2=com_data;
		read_byte();
		check_date=com_data;
		dh=1;
		temp=(RH_date1+RH_date2+T_date1+T_date2); //����У��
		if(temp==check_date)
		{
			RH_temp1=RH_date1;
			RH_temp2=RH_date2;
			T_temp1=T_date1;
			T_temp2=T_date2;
		}
	}
	delay100us(1000);//ÿ�ζ�dht11���1s����
}
/*************************************24c02**************************************/
void delay5us()
{ ;; }

void start()
{
	sda=1;
	delay5us();
	scl=1;
	delay5us();
	sda=0;
	delay5us();
}


void stop()
{
	sda=0;
	delay5us();
	scl=1;
	delay5us();
	sda=1;
	delay5us();
}

void respons()
{
	uchar i;
	scl=1;
	delay5us();
	while(sda==1&&i<255)
		i++;
	scl=0;
	delay5us();	
}

void write_date(uchar date)
{
	uchar i,temp;
	temp=date;
	for(i=0;i<8;i++)
	{
		temp<<=1;
		scl=0;
		delay5us();
		sda=CY;
		delay5us();
		scl=1;
		delay5us();
	}
	scl=0;
	delay5us();
	sda=1;
	delay5us();
}

uchar read_date()
{
	 uchar i,j,k;
	 scl=0;
	 delay5us();
	 sda=1;
	 delay5us();
	 for(i=0;i<8;i++)
	 {
	 	scl=1;
		delay5us();
		if(sda==1)
		   j=1;
		else
		   j=0;
		k=k<<1|j;
		scl=0;
		delay5us();
	 }
	 return k;
}

void iic24c_init()
{
	scl=1;
	delay5us();
	sda=1;
	delay5us();
}

void write_add(uchar address,uchar date)
{
	start();
	write_date(0xa0);
	respons();
	write_date(address);
	respons();
	write_date(date);
	respons();
	stop();
}

uchar read_add(uchar address)
{
	uchar date;
	start();
	write_date(0xa0);
	respons();
	write_date(address);
	respons();
	start();
	write_date(0xa1);
	respons();
	date=read_date();
	stop();
	return date;
}
/*************************************������************************************/
void main()
{
	int shidu[]={0,0};
	int i,RH_H,iic_date;
	init();
	iic24c_init();
	while(1)
	{
		RH();
		RH_H=RH_temp1;
		write_add(0x03,RH_H);
		delay(100);
		iic_date=read_add(0x03);
		shidu[0]=0x30+iic_date/10;
		shidu[1]=0x30+iic_date%10;
		dizhi(1,0);
		for(i=0;i<2;i++)
		{
			write_data(shidu[i]);
		}

	}
}