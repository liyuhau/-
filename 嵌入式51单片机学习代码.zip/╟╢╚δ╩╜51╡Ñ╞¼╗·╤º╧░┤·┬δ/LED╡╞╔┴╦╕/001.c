#include<reg51.h>
void yanshi(unsigned int k)
{
    unsigned int i,j;
	for(i=k;i>0;i--)
	 for(j=200;j>0;j--);
}
sbit D1=P1^0;
sbit D2=P1^1;
sbit D3=P1^2;
sbit D4=P1^3;
void main()
{
    for(;;)
    {
	    D1=0;
		yanshi(600);
		D1=1;
		yanshi(600);
		D2=0;
		yanshi(600);
		D2=1;
		yanshi(600);
		D3=0;
		yanshi(600);
		D3=1;
		yanshi(600);
		D4=0;
		yanshi(600);
		D4=1;
		yanshi(600); 
	    P1=0x00;
     	yanshi(600);
	    P1=0xff;
	    yanshi(600);
	}
}