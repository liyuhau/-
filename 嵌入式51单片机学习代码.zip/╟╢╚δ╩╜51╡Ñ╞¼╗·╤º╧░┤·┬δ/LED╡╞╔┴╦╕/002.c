#include<reg51.h>
unsigned int a;
void main()
{
    while(1)
	{
        unsigned int i;
        a=50000;
	    P1=0xf7;
	    while(a--);
	    for(i=8;i>0;i++)
	    {
	       a=50000;
	       P1>>=1;
	       while(a--);
	    }
	    a=50000;
	    P1=0xff;
	    while(a--);
	}
}