#include<reg51.h>
sbit a=P0^0;
sbit b=P0^1;
void delay()
{
	int i,j;
	for(i=100;i>0;i--)
	 for(j=1000;j>0;j--);
}
void main()
{	a=1;
	b=0;

}