 #include<reg51.h>
 void delay_ms(int time)
 {
 	int i,j;
 	for(i=time;i>0;i--)
	for(j=110;j>0;j--);
 }
void main()
{
	int a,b,i;
	b=0xf7;
	while(1)
	{
		for(i=0;i<3;i++)
		{
			P1=b;
			delay_ms(1000);
			b=b>>1;
		}
		delay_ms(1000);
		for(i=0;i<3;i++)
		{
			b=b<<1;
			b=b|0x01;
			P1=b;
			delay_ms(1000);
		}
	}
}