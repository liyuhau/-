#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char
sbit dula=P2^6;
sbit wela=P2^7;
uchar code table[]={
0x3f,0x06,0x5d,0x4f,
0x66,0x6d,0x7d,0x07,
0x7f,0x6f,0x77,0x7c,
0x39,0x5e,0x79,0x71,
0x76,0x79,0x38,0x3f};
uchar sum=0,num=0;
uchar bai,shi,ge,flag,flag1;
uint shu=432;
void display(uchar aa,uchar bb,uchar cc,uchar bai,uchar shi,uchar ge);
void delay(uint k);
void init();
void main()
{  
     init();
	 while(1)
	 {
	     if(flag1!=1)
	        display(7,6,5,bai,shi,ge);
		 else
	        display(16,17,18,18,19,20);
   	}	 
}
void init()
{
    uint a=1;
    P1=0xf7;
	TMOD=0x11;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	TH1=(65536-50000)/256;
	TL1=(65536-50000)%256;
	EA=1;
	ET0=1;
	ET1=1;
	TR0=1;
	TR1=1;
	while(1)
	{
	    if(flag!=1)
		{
		  if(sum==10)
		  {
			    sum=0;
				P1>>=1;
				a++;
				if(a==5)
			    {
				    P1=0x00;
					delay(500);
					P1=0xff;
					delay(500);
					P1=0xf7;
					a=1;
			    }
		  }
		}
	    else
		{
		    if(sum%4==0)
			  P1=~P1;
			if(sum==60)
			{  TR0=0;
			  P1=0xff;
			  flag1=1;
			}
		}
	}
}
void display(uchar aa,uchar bb,uchar cc,uchar bai,uchar shi,uchar ge)
{
	dula=1;
	P0=table[aa];
	dula=0;
	P0=0xff;
	wela=1;
	P0=0xfe;
	wela=0;
	delay(5);

	dula=1;
	P0=table[bb];
	dula=0;
	P0=0xff;
	wela=1;
	P0=0xfd;
	wela=0;
	delay(5);

	dula=1;
	P0=table[cc];
	dula=0;
	P0=0xff;
	wela=1;
	P0=0xfb;
	wela=0;
	delay(5);

    dula=1;
	P0=table[bai];
	dula=0;
	P0=0xff;//��ֹ�����ֻ��������ʱ�������������δ������˸����
	wela=1;
	P0=0xf7;
	wela=0;
	delay(5);

	dula=1;
	P0=table[shi];
	dula=0;
	P0=0xff;
	wela=1;
	P0=0xef;
	wela=0;
	delay(5);

	dula=1;
	P0=table[ge];
	dula=0;
	P0=0xff;
	wela=1;
	P0=0xdf;
	wela=0;
	delay(5);
}
void delay(uint k)
{
    uint i,j;
	for(i=k;i>0;i--)
	 for(j=100;j>0;j--);
}
void time0_() interrupt 1
{
    TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	sum++;  
}
void time1_() interrupt 3
{
    TH1=(65536-50000)/256;
	TL1=(65536-50000)%256;
	num++;
	if(num==2)
	{
	    num=0;
		shu--;
		bai=shu/100;
		shi=shu%100/10;
		ge=shu%10;
		if(shu==398)
		{
		      TR0=0;
			  TH0=(65536-50000)/256;
	          TL0=(65536-50000)%256;
			  flag=1;
			  TR0=1;
			  sum=0;
			  TR1=0;
		}
	}  
}