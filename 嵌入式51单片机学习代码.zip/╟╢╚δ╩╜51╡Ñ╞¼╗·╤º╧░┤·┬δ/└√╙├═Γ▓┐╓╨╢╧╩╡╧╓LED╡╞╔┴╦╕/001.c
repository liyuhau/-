#include<reg51.h>
#define  uint unsigned int 
void yanshi()
{
    uint i,j;
	for(i=2000;i>0;i--)
	 for(j=500;j>0;j--);  
}
void main()
{
     uint k;
     P1=0xf7;
	 yanshi();
	 EA=1;
	 EX0=1;
	 IT0=1;
	 for(k=8;k>0;k--)
     {
	     P1>>=1;
	     yanshi(); 
     }
}
void enter() interrupt 0
{
     P1=~P1;
}