#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit scl=P2^6;
sbit sda=P2^7;
void delay()
{ ;; }

void delay1(uchar z)
{
	uchar i,j;
	for(i=z;i>0;i--)
	 for(j=100;j>0;j--);
}
void start()
{
	sda=1;
	delay();
	scl=1;
	delay();
	sda=0;
	delay();
}


void stop()
{
	sda=0;
	delay();
	scl=1;
	delay();
	sda=1;
	delay();
}

void respons()
{
	uchar i;
	scl=1;
	delay();
	while((sda==1)&&(i<255))
	i++;
	scl=0;
	delay();	
}

void write_byte(uchar date)
{
	uchar i,temp;
	temp=date;
	for(i=0;i<8;i++)
	{
		temp<<=1;
		scl=0;
		delay();
		sda=CY;
		delay();
		scl=1;
		delay();
	}
	scl=0;
	delay();
	sda=1;
	delay();
}

uchar read_byte()
{
	 uchar i,j,k;
	 scl=0;
	 delay();
	 sda=1;
	 delay();
	 for(i=0;i<8;i++)
	 {
	 	scl=1;
		delay();
		if(sda==1)
		   j=1;
		else
		   j=0;
		k=(k<<1)|j;
		scl=0;
		delay();
	 }
	 return k;
}
	
void init()
{
	scl=1;
	delay();
	sda=1;
	delay();
}

void write_add(uchar address,uchar date)
{
	start();
	write_byte(0xa0);
	respons();
	write_byte(address);
	respons();
	write_byte(date);
	respons();
	stop();
}

uchar read_add(uchar address)
{
	uchar date;
	start();
	write_byte(0xa0);
	respons();
	write_byte(address);
	respons();
	start();
	write_byte(0xa1);
	respons();
	date=read_byte();
	stop();
	return date;
}
void main()
{
	init();
	write_add(0x03,0x01);
	delay1(100);
	P1=read_add(0x03);
	while(1);
}
