#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char
uint sum=0;
void yanshi()
{
    uint k,j;
	for(k=500;k>0;k--)
	 for(j=200;j>0;j--);
}
void main()
{
    uint i=0;
    P1=0xf7;
    TMOD=0x02;
	TH0=0x06;
	TL0=0x06;
	EA=1;
	ET0=1;
	TR0=1;
    while(1)
	{	 
	     if(sum==4000)
		 { 
		     sum=0;
			 P1>>=1;
			 i++;
			 if(i==9)
			 {
			     P1=0xff;
				 yanshi();
				 P1=0xf7;
				 i=0;
			 }
		 }
	     
		   
}
}
void T0_time() interrupt 1
{
	sum++; 
}