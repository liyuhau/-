#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char
uint sum=0;
void yanshi()
{
    uint k,j;
	for(k=500;k>0;k--)
	 for(j=200;j>0;j--);
}
void main()
{
	uint i=0;
	P1=0xf7;
	TMOD=0x00;
	TH0=(8192-5000)/32;
	TL0=(8192-5000)%32;
	EA=1;
	ET0=1;
	TR0=1;
    while(1)
	{	 
	     if(sum==200)
		 { 
		     sum=0;
			 P1>>=1;
			 i++;
			 if(i==9)
			 {
			     P1=0xff;
				 yanshi();
				 P1=0xf7;
				 i=0;
			 }
		 }
	     
		   
}
}
void T0_time() interrupt 1
{
    TH0=(8192-5000)/32;
	TL0=(8192-5000)%32;
	sum++; 
}
