package ʵ��11��ȡ����;
import java.sql.*;
import java.util.*;
public class RandomGetRecord {
	public static void main(String[] args) {
	
		int wantRecordAmount = 3;
		Random random = new Random();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}
		catch(ClassNotFoundException e) {
			System.out.print(e);
		}
		Connection con;
		Statement sql;
		ResultSet rs;
		try {
			String uri = "jdbc:mysql://localhost:3306/shop?useSSL=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC&rewriteBatchedStatements=true";
			String id = "root";
			String password = "111111";
			con = DriverManager.getConnection(uri,id,password);
			sql = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = sql.executeQuery("SELECT * FROM goods");
			rs.last();
			int count = rs.getRow();
			Vector<Integer> vector = new Vector<Integer>();
			for(int i=1;i<=count;i++)
			{
				vector.add(new Integer(i));
			}
			int itemAmount =Math.min(wantRecordAmount, count);
			System.out.println("�����ȡ" + itemAmount + "����¼.");
			double sum = 0,n=itemAmount;
			while(itemAmount>0)
			{
				int randomIndex = random.nextInt(vector.size());
				int index = (vector.elementAt(randomIndex)).intValue();
				rs.absolute(index);
				String number = rs.getString(1);
				String name = rs.getString(2);
				java.util.Date date = rs.getDate(3);
				double price = rs.getDouble(4);
				sum = sum+price;
				itemAmount--;
				vector.removeElement(randomIndex);
			}
			con.close();
			double aver =sum/n;
			System.out.println("���ۣ�" + aver + "Ԫ");
		}
		catch (SQLException e) {
			System.out.println("" + e);
		}
	}

}
