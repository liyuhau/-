package ʵ��11�û�ת��;
import java.sql.*;
public class TurnMoney {
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		Connection con = null;
		Statement sql;
		ResultSet rs;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e) {
			System.out.println("" + e);
		}
		try {
			double n =100;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?useSSL=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC&rewriteBatchedStatements=true","root","111111");
			con.setAutoCommit(false);
			sql = con.createStatement();
			rs = sql.executeQuery("SELECT * FROM car1 WHERE name='zhangsan'");
			rs.next();
			double amountOne = rs.getDouble("amount");
			System.out.println("ת��֮ǰzhangsan��Ǯ������:" + amountOne);
			rs = sql.executeQuery("SELECT * FROM car2 WHERE name='xidanShop'");
			rs.next();
			double amountTwo = rs.getDouble("amount");
			System.out.println("ת��֮ǰxidanShop��Ǯ������:" + amountTwo);
			amountOne = amountOne-n;
			amountTwo = amountTwo+n;
			sql.executeUpdate("UPDATE card1 SET amount =" + amountOne + " WHERE name='zhangsan'");
			sql.executeUpdate("UPDATE card2 SET amount =" + amountTwo + " WHERE name='xidanShop'");
			con.commit();
			con.setAutoCommit(true);
			rs = sql.executeQuery("SELECT * FROM car1 WHERE name='zhangsan'");
			rs.next();
			amountOne = rs.getDouble("amount");
			System.out.println("ת�˲�����zhangsan��Ǯ������:" + amountOne);
			rs = sql.executeQuery("SELECT * FROM car2 WHERE name='xidanShop'");
			rs.next();
			amountTwo = rs.getDouble("amount");
			System.out.println("ת�˲���֮��xidanShop��Ǯ������:" + amountTwo);
			con.close();
			
		}
		catch(SQLException e) {
			try {
				con.rollback();
			}
			catch(SQLException exp) {
				System.out.println(e.toString());
			}
		}
	}
}
