package ʵ��4������;

public class Vehicle {
	double speed=0;
	int power=0;
	void speedUp(int s)
	{
		 speed+=s;
	}
	void speedDown(int d)
	{
		speed-=d;
	}
	void setPower(int p)
	{
		power=p;
	}
	int getPower()
	{
		return power;
	}
	double getSpeed()
	{
		return speed;
	}
}

