package ʵ��4�󷽳̵ĸ�;

public class SunRise {
	public static void main(String args[])
	{
		SquareEquation e=new SquareEquation(4,5,1);
		e.getRoots();
		System.out.println();
		e.setEfficient(-3, 4, 5);
		e.getRoots();
		//e.setEfficient(0, 4, 5);
		//e.getRoots();
	}
}
