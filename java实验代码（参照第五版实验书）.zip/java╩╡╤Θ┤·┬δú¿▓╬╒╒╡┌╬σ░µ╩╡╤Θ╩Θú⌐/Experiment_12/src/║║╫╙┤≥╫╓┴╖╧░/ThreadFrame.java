package ���Ӵ�����ϰ;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ThreadFrame extends Frame implements ActionListener{
	JTextField showWord;
	JButton button;
    JTextField inputText,showScore;
    WordThread giveWord;
    int score = 0;
    ThreadFrame(){
    	showWord = new JTextField(6);
    	showWord.setFont(new Font("",Font.BOLD,72));
    	showWord.setHorizontalAlignment(showWord.CENTER);
    	giveWord = new WordThread();
    	giveWord.setJTextField(showWord);
    	giveWord.setSleepLength(5000);
    	button=new JButton("��ʼ");
    	inputText = new JTextField(10);
    	showScore=new JTextField(5);
    	showScore.setEditable(false);
    	button.addActionListener(this);
    	inputText.addActionListener(this);
    	add(button,BorderLayout.NORTH);
    	add(showWord,BorderLayout.CENTER);
    	JPanel southP=new JPanel();
    	southP.add(new JLabel("���뺺�ֺ�(�س�):"));
    	southP.add(inputText);
    	southP.add(showScore);
    	add(southP,BorderLayout.SOUTH);
    	setBounds(100,100,350,180);
    	setVisible(true);
    	validate();
    	addWindowListener(new WindowAdapter(){
    		public void windowClosing(WindowEvent e){
    			System.exit(0);
    	    }
    	});
   }
  
public void actionPerformed(ActionEvent e){
	   if(e.getSource() == button) {
		   if(!(giveWord.isAlive())) {
			   giveWord = new WordThread();
			   giveWord.setJTextField(showWord);
			   giveWord.setSleepLength(5000);
		   }
		   try {
			   giveWord.start();
		   }
		   catch(Exception exe){}
	   }
	   else if(e.getSource() == inputText) {
		   if(inputText.getText().contentEquals(showWord.getText()))
			   score++;
		   showScore.setText("�÷֣�"+score);
		   inputText.setText(null);
	   }
   }
}
